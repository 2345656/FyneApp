//go:build release
// +build release

package app

import "fyne.io/fyne/v2"

const buildMode = fyne.BuildRelease
